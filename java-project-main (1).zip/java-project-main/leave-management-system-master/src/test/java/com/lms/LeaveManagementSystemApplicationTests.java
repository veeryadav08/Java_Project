package com.lms;



/*@RunWith(SpringRunner.class)
@SpringBootTest*/
public class LeaveManagementSystemApplicationTests {

	//@Test
	public void contextLoads() {
	}

}
